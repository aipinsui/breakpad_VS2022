void cc_fun() {}
