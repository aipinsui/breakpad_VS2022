void objc_fun() { }
