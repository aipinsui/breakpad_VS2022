int f();
int main() {
  return f();
}
