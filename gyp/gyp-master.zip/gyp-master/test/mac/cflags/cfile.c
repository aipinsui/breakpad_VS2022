#ifndef CFLAG
#error CFLAG should be set
#endif

#ifdef CCFLAG
#error CCFLAG should not be set
#endif
